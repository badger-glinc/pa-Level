
import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [message, setMessage] = useState('');
  const [listings, setListings] = useState([]);
  const [form, setForm] = useState({ name: '', location: '', price: '', contact: '' });

  useEffect(() => {
    fetch('/api/hello')
      .then(res => res.json())
      .then(data => setMessage(data.message))
      .catch(() => setMessage('Failed to connect to backend.'));

    fetch('/api/listings')
      .then(res => res.json())
      .then(data => setListings(data));
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('/api/listings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
    .then(res => res.json())
    .then(newListing => {
      setListings([...listings, newListing]);
      setForm({ name: '', location: '', price: '', contact: '' });
    });
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>🏠 PaLevel</h1>
        <p>{message}</p>
        <p>Student Accommodation Finder for Zambia</p>
        <p style={{ fontStyle: 'italic', fontSize: '0.9rem', marginTop: '20px' }}>By Goronga Charles Makuwerere</p>
      </header>
      <main>
        <section>
          <h2>Find Your Room</h2>
          <ul>
            {listings.map(listing => (
              <li key={listing.id} style={{ marginBottom: '10px' }}>
                <strong>{listing.name}</strong> - {listing.location} - ZMW {listing.price} <br /> Contact: {listing.contact}
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2>Landlords: Add Your Property</h2>
          <form onSubmit={handleSubmit} className="listing-form">
            <input name="name" value={form.name} onChange={handleChange} placeholder="Property Name" required />
            <input name="location" value={form.location} onChange={handleChange} placeholder="Location" required />
            <input name="price" value={form.price} onChange={handleChange} placeholder="Price" required />
            <input name="contact" value={form.contact} onChange={handleChange} placeholder="Contact Info" required />
            <button type="submit">Add Listing</button>
          </form>
        </section>
      </main>
      <footer>
        <p>© {new Date().getFullYear()} PaLevel. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;
