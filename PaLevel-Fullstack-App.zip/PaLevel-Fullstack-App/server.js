
const express = require('express');
const path = require('path');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.get('/api/hello', (req, res) => {
  res.json({ message: 'Welcome to PaLevel API!' });
});

let listings = [];

app.post('/api/listings', (req, res) => {
  const { name, location, price, contact } = req.body;
  if (!name || !location || !price || !contact) {
    return res.status(400).json({ error: 'All fields are required.' });
  }
  const newListing = { id: Date.now(), name, location, price, contact };
  listings.push(newListing);
  res.status(201).json(newListing);
});

app.get('/api/listings', (req, res) => {
  res.json(listings);
});

app.get('/test', (req, res) => {
  res.send('<h1>🚀 PaLevel Backend Running</h1>');
});

const frontendBuildPath = path.join(__dirname, 'frontend', 'build');
app.use(express.static(frontendBuildPath));

app.get('*', (req, res) => {
  res.sendFile(path.join(frontendBuildPath, 'index.html'));
});

app.listen(PORT, () => console.log(`🚀 PaLevel backend running on port ${PORT}`));
